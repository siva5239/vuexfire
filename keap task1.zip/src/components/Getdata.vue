<template>

  <div>
    
    <h1>Display data</h1>
    <div class="search-wrapper panel-heading col-sm-12">
       <p class="float-left"><b>{{data.length}}</b> :Result</p>
      <input type="text" v-model="search" placeholder="Search here" /> 
     
     
      <label for="pagination">:perpage</label>
      <select>
         <option v-for="perpage of perpagerecords" :key="perpage">{{perpage}}</option>
        
      </select>
       
    </div>
    
   
    <table class="table table-bordered">
      <tr>
        <th>
          <label class="form-checkbox">
            <input type="checkbox" v-model="selectAll" @click="select" />
            <i class="form-icon"></i>
          </label>
        </th>
        <th>Id</th>
        <th>CompanyName</th>
        <th>Email</th>
        <th>State</th>
      </tr>
      <tr v-for="(user,i) in filterdata " :key="i">
        <td>
          <label class="form-checkbox">
            <input type="checkbox" :value="user.id" v-model="selected" />
            <i class="form-icon"></i>
          </label>
        </td>
        <td>{{ i+1 }}</td>
        <td>{{ user.CompanyName }}</td>
        <td>{{ user.email }}</td>
        <td>{{ user.state }}</td>
      </tr>
    </table>
  </div>
</template>
<script>
import axios from "axios";

export default {
  name: "GetData",
  data() {
    return {
      userdetails: [],
      search: "",
      selectedAll: true,
      selected: [],
      data: [],
      perpagerecords:[3,6,9,12]
     
    };
  },
  computed: {
    // filteredProducts() {
    //   return this.userdetails.filter((p) => {
    //     return true if the product should be visible

    //     in this example we just check if the search string
    //     is a substring of the product name (case insensitive)
    //     return p.this.search.toLowerCase().split('').every(v=>p.companyName.toLowerCase().includes(v))
    //   ;
    //   });
    // },
    filterdata() {
      return this.data.filter((post) => {
        return post.CompanyName.toLowerCase().includes(
          this.search.toLowerCase()
        );
      });
    },
  },
  mounted() {
    this.adddata();
  },
  methods: {
    adddata() {
      console.log(this.userdetails);
      axios
        .get("https://vue-firebase-267f6-default-rtdb.firebaseio.com/post.json")
        .then((response) => {
          this.userdetails = response.data;

          // this.userdetails=res;
          console.log(this.userdetails);

          Object.keys(this.userdetails).forEach((result) => {
            console.log(result);
            this.data.push(this.userdetails[result]);
          });
        });
    },
    select() {
      this.selected = [];
      if (!this.selectAll) {
        for (let i in this.userdetails) {
          this.selected.push(this.userdetails[i].id);
        }
      }
    },
   
   
 }
};

</script>
<style scoped>
table {
  margin-top: 30px;
}
p{
  margin-right: 934px;
  margin: 0px;
  padding: 0px;
}

</style>